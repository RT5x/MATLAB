% lab06.m                                                                         
% aghatta@calpoly.edu

close all;
clear;
format short;
format compact;

%% p01

format long;
p01fig = figure;
tl = tiledlayout(2,2);
